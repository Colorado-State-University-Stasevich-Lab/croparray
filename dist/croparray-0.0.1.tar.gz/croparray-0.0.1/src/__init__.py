# -*- coding: utf-8 -*-
"""
Created on Nov 26 2021

@author: Tim Stasevich
"""
name = 'crop_array_tools'